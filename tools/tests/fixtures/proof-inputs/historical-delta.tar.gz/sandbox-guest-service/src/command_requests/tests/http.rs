use super::*;
use crate::command_requests::http::{Error as SelectionError, Rpc};
use axum::http::Method;

#[path = "http/gzip.rs"]
mod gzip;

#[tokio::test]
async fn oversized_body_replies_without_dispatch_and_keeps_the_original_request_slot() {
    let session = session().await;
    let pool = CommandRequests::new(limits()).unwrap();
    for rpc in [Rpc::SendInput, Rpc::Start] {
        let mut h = headers();
        h.insert(
            "content-type",
            if rpc.is_stream() {
                "application/connect+json"
            } else {
                "application/json"
            }
            .parse()
            .unwrap(),
        );
        let selected = prepare_headers(&pool, &session, h)
            .await
            .select_json(&Method::POST, rpc)
            .unwrap();
        let original = selected.deadline();
        let failure = selected
            .decode(Body::from(vec![b' '; 65537]))
            .await
            .err()
            .unwrap();
        assert_eq!(failure.error(), &SelectionError::Request(Error::BodyLimit));
        assert_eq!(failure.deadline(), original);
        full(&pool);
        let response = failure
            .into_response(crate::command_requests::http::reply::Limits {
                wire_bytes: 4096,
                chunk_bytes: 4096,
            })
            .await
            .unwrap();
        assert_eq!(
            response.status(),
            if rpc.is_stream() {
                axum::http::StatusCode::OK
            } else {
                axum::http::StatusCode::TOO_MANY_REQUESTS
            }
        );
        let mut body = response.into_body();
        let bytes = body.frame().await.unwrap().unwrap().into_data().unwrap();
        let expected = br#"{"code":"resource_exhausted","message":"command request exceeds configured body limits"}"#;
        if rpc.is_stream() {
            assert_eq!(bytes[0], 2);
            assert_eq!(
                &bytes[5..],
                [b"{\"error\":".as_slice(), expected, b"}"].concat()
            );
        } else {
            assert_eq!(bytes.as_ref(), expected);
        }
        drop(body);
        full(&pool);
        drop(bytes);
        released(&pool).await;
        // A later independently admitted request still decodes normally.
        let mut h = headers();
        h.insert("content-type", "application/json".parse().unwrap());
        let ready = prepare_headers(&pool, &session, h)
            .await
            .select_json(&Method::POST, Rpc::List)
            .unwrap()
            .decode(Body::from("{}"))
            .await
            .unwrap();
        assert_eq!(ready.request(), &Request::List);
        drop(ready);
    }
}

fn unread() -> Body {
    Body::from_stream(stream::poll_fn(
        |_| -> Poll<Option<Result<Bytes, std::io::Error>>> {
            panic!("rejected HTTP selection polled body")
        },
    ))
}
async fn prepare_headers(
    pool: &CommandRequests,
    session: &Session<Meta>,
    h: HeaderMap,
) -> Prepared {
    let accounts = AccountPool::new(
        Accounts(Arc::new(AtomicUsize::new(0))),
        1,
        Duration::from_secs(5),
    )
    .unwrap();
    pool.admit()
        .unwrap()
        .authenticate(session, h)
        .await
        .unwrap()
        .prepare(&accounts, context_limits())
        .await
        .unwrap()
}

#[tokio::test]
async fn http_selection_failures_keep_original_capacity_without_holding_completed_auth() {
    let session = session().await;
    let pool = CommandRequests::new(limits()).unwrap();
    for case in 0..6 {
        let mut h = headers();
        h.insert("content-type", "application/connect+json".parse().unwrap());
        let method = if case == 0 { Method::GET } else { Method::POST };
        match case {
            1 => {
                h.insert("content-type", "invalid".parse().unwrap());
            }
            2 => {
                h.insert("connect-content-encoding", "br".parse().unwrap());
            }
            3 => {
                h.insert("connect-protocol-version", "bad".parse().unwrap());
            }
            4 => {
                h.insert("connect-timeout-ms", "bad".parse().unwrap());
            }
            _ => {}
        }
        let prepared = prepare_headers(&pool, &session, h).await;
        let deadline = prepared.deadline();
        if case == 5 {
            tokio::time::pause();
            tokio::time::advance(Duration::from_secs(31)).await;
            tokio::time::resume();
        }
        let failure = prepared.select_json(&method, Rpc::Start).err().unwrap();
        assert_eq!(failure.deadline(), deadline);
        assert!(matches!(
            (case, failure.error()),
            (0, SelectionError::Method { head: false })
                | (1, SelectionError::ContentType)
                | (2, SelectionError::Compression(_))
                | (3, SelectionError::Version(_))
                | (4, SelectionError::Timeout(_))
                | (5, SelectionError::Request(Error::DeadlineExceeded))
        ));
        full(&pool);
        // A response/failure retains capacity, not a completed auth read lock.
        tokio::time::timeout(
            Duration::from_secs(1),
            session.initialize(br#"{"accessToken":"token"}"#),
        )
        .await
        .unwrap()
        .unwrap();
        drop(failure);
        released(&pool).await;
    }
}

#[tokio::test]
async fn identity_decoder_rejects_expired_or_gzip_request_before_reading_and_keeps_ready_ownership()
{
    let session = session().await;
    let pool = CommandRequests::new(limits()).unwrap();
    for field in ["connect-content-encoding", "connect-timeout-ms"] {
        let mut h = headers();
        h.insert("content-type", "application/connect+json".parse().unwrap());
        h.insert(
            field,
            if field == "connect-timeout-ms" {
                "0"
            } else {
                "gzip"
            }
            .parse()
            .unwrap(),
        );
        let selected = prepare_headers(&pool, &session, h)
            .await
            .select_json(&Method::POST, Rpc::Start)
            .unwrap();
        let deadline = selected.deadline();
        let failure = selected.decode_identity(unread()).await.err().unwrap();
        assert_eq!(failure.deadline(), deadline);
        assert_eq!(
            failure.error(),
            &if field == "connect-timeout-ms" {
                SelectionError::Request(Error::DeadlineExceeded)
            } else {
                SelectionError::EncodingNotImplemented
            }
        );
        full(&pool);
        drop(failure);
        released(&pool).await;
    }
    let mut h = headers();
    h.insert(
        "content-type",
        "APPLICATION/JSON; charset=\"UTF-8\"".parse().unwrap(),
    );
    h.insert("content-encoding", "identity".parse().unwrap());
    h.insert("connect-timeout-ms", "1000".parse().unwrap());
    let selected = prepare_headers(&pool, &session, h)
        .await
        .select_json(&Method::POST, Rpc::List)
        .unwrap();
    assert_eq!(selected.content_type(), "application/json; charset=utf-8");
    let deadline = selected.deadline();
    let ready = selected.decode_identity(Body::from("{}")).await.unwrap();
    assert_eq!(ready.deadline(), deadline);
    assert_eq!(ready.request(), &Request::List);
    full(&pool);
    drop(ready);
    released(&pool).await;
}

#[tokio::test]
async fn selected_success_keeps_gzip_format_deadline_and_original_request_capacity() {
    use crate::command_requests::http::response;
    use sandproof_guest_runtime::gzip::{DecodeLimits, Decoder};
    let session = session().await;
    let pool = CommandRequests::new(limits()).unwrap();
    for content_type in ["application/json", "application/json; charset=utf-8"] {
        let mut h = headers();
        h.insert("content-type", content_type.parse().unwrap());
        h.insert("accept-encoding", "gzip".parse().unwrap());
        let selected = prepare_headers(&pool, &session, h)
            .await
            .select_json(&Method::POST, Rpc::List)
            .unwrap();
        let deadline = selected.deadline();
        let ready = selected.decode_identity(Body::from("{}")).await.unwrap();
        let reply = ready
            .execute_pid(&registry(), response_limits())
            .await
            .unwrap();
        assert_eq!(reply.deadline(), deadline);
        let response = reply
            .into_http_response(response::Limits {
                wire_bytes: 4096,
                chunk_bytes: 4096,
            })
            .await
            .unwrap();
        assert_eq!(response.headers()["content-type"], content_type);
        assert_eq!(response.headers()["content-encoding"], "gzip");
        assert_eq!(response.headers()["accept-encoding"], "gzip");
        session
            .initialize(br#"{"accessToken":"token"}"#)
            .await
            .unwrap();
        let mut body = response.into_body();
        let bytes = body.frame().await.unwrap().unwrap().into_data().unwrap();
        let mut decoder = Decoder::new(
            bytes.as_ref(),
            DecodeLimits {
                encoded_bytes: 4096,
                decoded_bytes: 4096,
                chunk_bytes: 4096,
                header_bytes: 4096,
                members: 8,
            },
        )
        .unwrap();
        assert_eq!(decoder.next_chunk().unwrap().unwrap(), b"{}");
        assert!(decoder.next_chunk().unwrap().is_none());
        drop(decoder);
        let copy = bytes.clone();
        drop(bytes);
        drop(body);
        full(&pool);
        drop(copy);
        released(&pool).await;
    }
    // The legacy decoder cannot invent a negotiated HTTP format after execution.
    let prepared = prepare_headers(&pool, &session, headers()).await;
    let deadline = prepared.deadline();
    let ready = prepared
        .decode("List", Body::from("{}"), deadline)
        .await
        .unwrap();
    let reply = ready
        .execute_pid(&registry(), response_limits())
        .await
        .unwrap();
    let failure = reply
        .into_http_response(response::Limits {
            wire_bytes: 4096,
            chunk_bytes: 4096,
        })
        .await
        .unwrap_err();
    assert_eq!(failure.error(), response::Error::UnclassifiedFault);
    assert_eq!(failure.deadline(), deadline);
    full(&pool);
    drop(failure);
    released(&pool).await;
}

#[tokio::test]
async fn selected_header_reply_keeps_original_admission_through_last_bytes_or_failed_encoding() {
    use crate::command_requests::http::reply;
    let session = session().await;
    let pool = CommandRequests::new(limits()).unwrap();
    for case in 0..5 {
        let mut h = headers();
        h.insert("content-type", "application/connect+json".parse().unwrap());
        h.insert("connect-accept-encoding", "gzip".parse().unwrap());
        h.insert("connect-protocol-version", "bad".parse().unwrap());
        if case == 1 {
            h.insert("connect-content-encoding", "br".parse().unwrap());
        } else if case == 2 {
            h.insert("connect-protocol-version", "1".parse().unwrap());
            h.insert("connect-timeout-ms", "bad".parse().unwrap());
        }
        let failure = prepare_headers(&pool, &session, h)
            .await
            .select_json(&Method::POST, Rpc::Start)
            .err()
            .unwrap();
        let original = failure.deadline();
        if case == 4 {
            tokio::time::pause();
            tokio::time::advance(Duration::from_secs(31)).await;
            tokio::time::resume();
        }
        let result = failure
            .into_header_response(reply::Limits {
                wire_bytes: if case == 3 { 1 } else { 16384 },
                chunk_bytes: 16384,
            })
            .await;
        if case >= 3 {
            let failure = result.unwrap_err();
            assert_eq!(failure.deadline(), original);
            assert_eq!(
                failure.error(),
                if case == 3 {
                    reply::Error::ResponseLimit
                } else {
                    reply::Error::DeadlineExceeded
                }
            );
            full(&pool);
            drop(failure);
        } else {
            let response = result.unwrap();
            assert_eq!(response.status(), 200);
            let mut body = response.into_body();
            let bytes = body.frame().await.unwrap().unwrap().into_data().unwrap();
            assert_eq!(bytes[0], if case == 1 { 2 } else { 3 });
            let copy = bytes.clone();
            drop(body);
            drop(bytes);
            full(&pool);
            tokio::time::timeout(
                Duration::from_secs(1),
                session.initialize(br#"{"accessToken":"token"}"#),
            )
            .await
            .unwrap()
            .unwrap();
            drop(copy);
        }
        released(&pool).await;
    }
}

#[tokio::test]
async fn original_head_method_failure_transfers_same_request_into_empty_response() {
    use crate::command_requests::http::reply;
    let session = session().await;
    let pool = CommandRequests::new(limits()).unwrap();
    for method in [Method::HEAD, Method::GET] {
        let mut h = headers();
        h.insert("content-type", "invalid".parse().unwrap());
        h.insert("connect-timeout-ms", "bad".parse().unwrap());
        let failure = prepare_headers(&pool, &session, h)
            .await
            .select_json(&method, Rpc::Start)
            .err()
            .unwrap();
        assert_eq!(
            failure.error(),
            &SelectionError::Method {
                head: method == Method::HEAD
            }
        );
        let response = failure
            .into_header_response(reply::Limits {
                wire_bytes: 1,
                chunk_bytes: 1,
            })
            .await
            .unwrap();
        assert_eq!(response.status(), 405);
        assert_eq!(
            response.headers().contains_key("content-length"),
            method != Method::HEAD
        );
        full(&pool);
        tokio::time::timeout(
            Duration::from_secs(1),
            session.initialize(br#"{"accessToken":"token"}"#),
        )
        .await
        .unwrap()
        .unwrap();
        let mut body = response.into_body();
        assert!(body.frame().await.is_none());
        released(&pool).await;
    }
}
